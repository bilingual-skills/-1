# English Last-Name Spelling Activity

This package is ready for GitHub Pages.

## Publish it

1. On GitHub, create a new **public repository**, for example `spelling-activity`.
2. Upload `index.html` to the repository's main branch.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then click **Save**.
6. After GitHub publishes it, your share link will look like:
   `https://YOUR-USERNAME.github.io/spelling-activity/`

## Important
The activity uses the browser microphone and speech recognition. Students should open the GitHub Pages HTTPS link in a supported browser such as Chrome or Edge and allow microphone access.

The final screen collects students' full names in the activity session.
